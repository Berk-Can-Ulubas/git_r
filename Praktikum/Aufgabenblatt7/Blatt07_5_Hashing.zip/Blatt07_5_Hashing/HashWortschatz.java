/**
 * Eine hashbasierte Implementation eines Wortschatzes.
 * 
 * @author  (your name)
 * @version (a version number or a date)
 */
class HashWortschatz implements Wortschatz
{

    /**
     * Initialisiert ein neues Exemplar von HashWortschatz.
     * 
     * @param berechner der Berechner, welcher die Hashfunktion umsetzt
     * @param groesse die (initiale) Gr��e der Hashtabelle
     */
    public HashWortschatz(HashWertBerechner berechner, int groesse)
    {
    }
    
    /**
     * F�gt ein Wort zum Wortschatz hinzu, sofern es noch nicht enthalten ist.
     * 
     * @param wort das hinzuzuf�gende Wort
     */
    public void fuegeWortHinzu(String wort)
    {
    }
    
    /**
     * Entfernt ein Wort aus dem Wortschatz, sofern es darin enthalten ist.
     * 
     * @param wort das zu entfernende Wort
     */
    public void entferneWort(String wort)
    {
    }
    
    /**
     * Gibt an, ob ein Wort im Wortschatz enthalten ist.
     * 
     * @param wort das zu �berpr�fende Wort
     * @return true, falls das Wort enthalten ist, false sonst
     */
    public boolean enthaeltWort(String wort)
    {
        return false;
    }
    
    /**
     * Gibt an, wieviele W�rter im Wortschatz enthalten sind.
     * 
     * @return die Anzahl der W�rter im Wortschatz
     */
    public int anzahlWoerter()
    {
        return 0;
    }

    /**
     * Schreibt den Wortschatz auf die Konsole (als Debugging-Hilfe gedacht).
     */
    public void schreibeAufKonsole()
    {
    }
    
    /**
     * Liefert den F�llgrad (Verh�ltnis W�rter zur Gr��e der Hash-Tabelle)
     */
    public int fuellgrad()
    {
        return 0;
    }
    
    /**
     * Liefert die l�ngste Kette an �berl�ufern.
     */
    public int laengsteKette()
    {
        return 0;
    }
}
